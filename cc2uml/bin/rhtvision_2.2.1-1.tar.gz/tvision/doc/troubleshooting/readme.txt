This directory contains test programs you can use to help the developer find
the origin of problems.
It was created in may 2003 to have a repository for tests oriented to find
problems found in Linux console for Red Hat 8.0.

SET
