#ifndef __STRSTREAM_H
#define __STRSTREAM_H

#include <strstrea.h>

#endif /*  __STRSTREAM_H */