#!/bin/sh
xgettext --default-domain=test --add-comments --keyword=_ --keyword=__ --omit-header  --add-location test.cc
