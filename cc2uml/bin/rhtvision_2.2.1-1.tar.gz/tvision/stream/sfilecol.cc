#ifndef NO_STREAM

#define Uses_TFileCollection
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass CLY_EXPORT RFileCollection( TFileCollection::name,
                                  TFileCollection::build,
                                  __DELTA(TFileCollection)
                                );

#endif

