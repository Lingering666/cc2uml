#ifndef NO_STREAM

#define Uses_TFrame
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass CLY_EXPORT RFrame( TFrame::name,
                         TFrame::build,
                         __DELTA(TFrame)
                       );

#endif
