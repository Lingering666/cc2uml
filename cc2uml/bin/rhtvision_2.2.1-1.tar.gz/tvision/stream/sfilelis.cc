#ifndef NO_STREAM

#define Uses_TFileList
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass CLY_EXPORT RFileList( TFileList::name,
                            TFileList::build,
                            __DELTA(TFileList)
                          );

#endif

