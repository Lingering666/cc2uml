#ifndef NO_STREAM

#define Uses_TResourceCollection
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass CLY_EXPORT RResourceCollection( TResourceCollection::name,
                                      TResourceCollection::build,
                                      __DELTA(TResourceCollection)
                                    );
#endif

