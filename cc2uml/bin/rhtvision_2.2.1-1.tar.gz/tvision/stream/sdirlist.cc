#ifndef NO_STREAM

#define Uses_TDirListBox
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass CLY_EXPORT RDirListBox( TDirListBox::name,
                              TDirListBox::build,
                              __DELTA(TDirListBox)
                            );

#endif

