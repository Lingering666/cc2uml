#ifndef NO_STREAM

#define Uses_TInputLine
#define Uses_TStreamableClass
#include <tv.h>
__link( RView )

TStreamableClass RInputLineU16( TInputLineU16::name,
                                TInputLineU16::build,
                                __DELTA(TInputLineU16)
                              );

#endif

