#ifndef NO_STREAM

#define Uses_TColorGroupList
#define Uses_TStreamableClass
#include <tv.h>
__link( RListViewer )

TStreamableClass CLY_EXPORT RColorGroupList( TColorGroupList::name,
                                  TColorGroupList::build,
                                  __DELTA(TColorGroupList)
                                );

#endif

