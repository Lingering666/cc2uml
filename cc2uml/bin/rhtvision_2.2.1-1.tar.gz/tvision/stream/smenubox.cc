#ifndef NO_STREAM

#define Uses_TMenuBox
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass CLY_EXPORT RMenuBox( TMenuBox::name,
                           TMenuBox::build,
                           __DELTA(TMenuBox)
                         );

#endif

