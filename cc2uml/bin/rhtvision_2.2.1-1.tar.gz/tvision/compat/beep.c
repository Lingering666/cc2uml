/*
 Copyright (C) 2000      Salvador E. Tropea
 Copyright (C) 2000      Anatoli Soltan
 Covered by the GPL license.
*/

#ifndef BEEP_DEFINED
void CLY_Beep(void)
{
}
#endif
